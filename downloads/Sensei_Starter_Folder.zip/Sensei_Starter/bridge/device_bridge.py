"""Sensei device bridge placeholder.

Replace this file with the bridge for your biosensor and validate its data
format before using it in a live study or classroom activity.
"""


def read_signal():
    raise NotImplementedError("Connect and implement your Sensei sensor bridge")


if __name__ == "__main__":
    print("Sensei placeholder: add your device bridge before running.")

