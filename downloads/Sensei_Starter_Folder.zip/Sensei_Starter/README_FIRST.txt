SENSEI STARTER FOLDER
=====================

This download is an example project structure for learning and classroom use.
It shows how Sensei configuration, a device bridge, a signal-to-behavior
mapping, and physical output code can live together in one legible folder.

Before running a real setup:

1. Replace the placeholder device bridge with the code for your biosensor.
2. Update sensei.config.json with your serial port and calibration values.
3. Edit programs/eda_to_lamp.json to match your interpretation and context.
4. Replace outputs/ambient_lamp.ino with tested firmware for your hardware.

The example files are intentionally non-operational placeholders. They do not
contain the complete Sensei research distribution or production device code.

