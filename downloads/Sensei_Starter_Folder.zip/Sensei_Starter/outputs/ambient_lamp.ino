/* Sensei ambient lamp placeholder.
 * Replace pin assignments and output behavior for your tested hardware.
 */

void setup() {
  // Configure your lamp hardware here.
}

void loop() {
  // Read Sensei state messages and render the chosen behavior here.
}

